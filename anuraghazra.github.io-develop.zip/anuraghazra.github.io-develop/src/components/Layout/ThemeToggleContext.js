import React from 'react';

const ThemeToggleContext = React.createContext();

export default ThemeToggleContext;
